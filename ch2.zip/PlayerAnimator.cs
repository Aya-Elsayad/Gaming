using UnityEngine;
using NeighboursFromHellVR.Player.Locomotion;

namespace NeighboursFromHellVR.Player
{
    /// <summary>
    /// Drives the player's full-body avatar Animator (visible to the player
    /// only in mirrors/cutscenes, since this is first-person VR) from
    /// locomotion speed, crouch state, and caught state. Distinct from
    /// <see cref="VRHands"/>, which animates the individual hand meshes.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class PlayerAnimator : MonoBehaviour
    {
        #region Inspector Fields

        [Header("References")]
        [SerializeField] private Animator _bodyAnimator;
        [SerializeField] private SmoothLocomotion _smoothLocomotion;
        [SerializeField] private PlayerController _playerController;
        [SerializeField] private PlayerHealth _playerHealth;

        [Header("Animation")]
        [SerializeField] private string _speedParameterName = "Speed";
        [SerializeField] private string _crouchParameterName = "IsCrouching";
        [SerializeField] private string _caughtParameterName = "IsCaught";
        [SerializeField] private float _speedBlendSpeed = 6f;

        #endregion

        #region Private Fields

        private int _speedParamHash;
        private int _crouchParamHash;
        private int _caughtParamHash;
        private float _currentBlendSpeed;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _speedParamHash = Animator.StringToHash(_speedParameterName);
            _crouchParamHash = Animator.StringToHash(_crouchParameterName);
            _caughtParamHash = Animator.StringToHash(_caughtParameterName);
        }

        private void OnEnable()
        {
            if (_playerController != null)
            {
                _playerController.CrouchStateChanged += HandleCrouchStateChanged;
            }

            if (_playerHealth != null)
            {
                _playerHealth.Caught += HandleCaught;
                _playerHealth.LivesReset += HandleLivesReset;
            }
        }

        private void OnDisable()
        {
            if (_playerController != null)
            {
                _playerController.CrouchStateChanged -= HandleCrouchStateChanged;
            }

            if (_playerHealth != null)
            {
                _playerHealth.Caught -= HandleCaught;
                _playerHealth.LivesReset -= HandleLivesReset;
            }
        }

        private void Update()
        {
            UpdateSpeedParameter();
        }

        #endregion

        #region Animation Updates

        /// <summary>Smoothly blends the Speed float toward the current locomotion magnitude.</summary>
        private void UpdateSpeedParameter()
        {
            if (_bodyAnimator == null || _smoothLocomotion == null)
            {
                return;
            }

            float targetSpeed = _smoothLocomotion.CurrentVelocity.magnitude;
            _currentBlendSpeed = Mathf.MoveTowards(_currentBlendSpeed, targetSpeed, _speedBlendSpeed * Time.deltaTime);

            _bodyAnimator.SetFloat(_speedParamHash, _currentBlendSpeed);
        }

        private void HandleCrouchStateChanged(bool isCrouched)
        {
            if (_bodyAnimator != null)
            {
                _bodyAnimator.SetBool(_crouchParamHash, isCrouched);
            }
        }

        private void HandleCaught(int remainingLives)
        {
            if (_bodyAnimator != null)
            {
                _bodyAnimator.SetBool(_caughtParamHash, true);
            }
        }

        private void HandleLivesReset(int lives)
        {
            if (_bodyAnimator != null)
            {
                _bodyAnimator.SetBool(_caughtParamHash, false);
            }
        }

        #endregion
    }
}
