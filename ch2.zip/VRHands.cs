using UnityEngine;
using UnityEngine.InputSystem;

namespace NeighboursFromHellVR.Player
{
    /// <summary>
    /// Drives the visual hand model for one controller: blends the grip/trigger
    /// Animator parameters from raw analog input, hides the hand mesh when the
    /// controller loses tracking, and swaps pose when the hand is holding an
    /// item versus empty (so fingers wrap around an object realistically).
    /// Reads analog grip/trigger values directly from the XR controller device
    /// rather than the digitally-thresholded actions used by
    /// <see cref="GrabSystem"/>, since animation needs the smooth 0-1 value.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class VRHands : MonoBehaviour
    {
        #region Inspector Fields

        [Header("References")]
        [Tooltip("Animator driving this hand's skinned mesh (Grip and Trigger float parameters).")]
        [SerializeField] private Animator _handAnimator;

        [Tooltip("Renderer(s) to disable when the controller is not tracked.")]
        [SerializeField] private Renderer[] _handRenderers;

        [Tooltip("The ObjectGrabber on this same hand, used to switch pose when holding an item.")]
        [SerializeField] private ObjectGrabber _objectGrabber;

        [Header("Input")]
        [Tooltip("Analog grip axis for this hand, e.g. <XRController>{LeftHand}/grip.")]
        [SerializeField] private InputActionReference _gripAnalogAction;

        [Tooltip("Analog trigger axis for this hand, e.g. <XRController>{LeftHand}/trigger.")]
        [SerializeField] private InputActionReference _triggerAnalogAction;

        [Tooltip("Device tracking-state action, used to detect when the controller is out of tracking range.")]
        [SerializeField] private InputActionReference _isTrackedAction;

        [Header("Animation")]
        [SerializeField] private string _gripParameterName = "Grip";
        [SerializeField] private string _triggerParameterName = "Trigger";
        [SerializeField] private string _holdingItemParameterName = "HoldingItem";
        [SerializeField] private float _blendSpeed = 18f;

        #endregion

        #region Private Fields

        private int _gripParamHash;
        private int _triggerParamHash;
        private int _holdingItemParamHash;

        private float _currentGripValue;
        private float _currentTriggerValue;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _gripParamHash = Animator.StringToHash(_gripParameterName);
            _triggerParamHash = Animator.StringToHash(_triggerParameterName);
            _holdingItemParamHash = Animator.StringToHash(_holdingItemParameterName);
        }

        private void OnEnable()
        {
            EnableAction(_gripAnalogAction);
            EnableAction(_triggerAnalogAction);
            EnableAction(_isTrackedAction);

            if (_objectGrabber != null)
            {
                _objectGrabber.ObjectGrabbed += HandleObjectGrabbed;
                _objectGrabber.ObjectReleased += HandleObjectReleased;
            }
        }

        private void OnDisable()
        {
            if (_objectGrabber != null)
            {
                _objectGrabber.ObjectGrabbed -= HandleObjectGrabbed;
                _objectGrabber.ObjectReleased -= HandleObjectReleased;
            }
        }

        private void Update()
        {
            UpdateTrackingVisibility();
            UpdateAnimatorBlend();
        }

        #endregion

        #region Input Helpers

        private static void EnableAction(InputActionReference reference)
        {
            if (reference != null && reference.action != null)
            {
                reference.action.Enable();
            }
        }

        #endregion

        #region Tracking Visibility

        /// <summary>
        /// Hides the hand mesh entirely when the controller reports as
        /// untracked, avoiding a hand model frozen mid-air at the last known
        /// pose - a common VR immersion breaker.
        /// </summary>
        private void UpdateTrackingVisibility()
        {
            if (_isTrackedAction == null || _isTrackedAction.action == null || _handRenderers == null)
            {
                return;
            }

            bool isTracked = _isTrackedAction.action.ReadValue<float>() > 0.5f;

            for (int i = 0; i < _handRenderers.Length; i++)
            {
                if (_handRenderers[i] != null)
                {
                    _handRenderers[i].enabled = isTracked;
                }
            }
        }

        #endregion

        #region Animation

        /// <summary>
        /// Smoothly blends the grip/trigger animator floats toward the raw
        /// analog input each frame, avoiding robotic snap-to-pose hands.
        /// </summary>
        private void UpdateAnimatorBlend()
        {
            if (_handAnimator == null)
            {
                return;
            }

            float targetGrip = _gripAnalogAction != null && _gripAnalogAction.action != null
                ? _gripAnalogAction.action.ReadValue<float>()
                : 0f;

            float targetTrigger = _triggerAnalogAction != null && _triggerAnalogAction.action != null
                ? _triggerAnalogAction.action.ReadValue<float>()
                : 0f;

            _currentGripValue = Mathf.MoveTowards(_currentGripValue, targetGrip, _blendSpeed * Time.deltaTime);
            _currentTriggerValue = Mathf.MoveTowards(_currentTriggerValue, targetTrigger, _blendSpeed * Time.deltaTime);

            _handAnimator.SetFloat(_gripParamHash, _currentGripValue);
            _handAnimator.SetFloat(_triggerParamHash, _currentTriggerValue);
        }

        #endregion

        #region Grab State

        private void HandleObjectGrabbed(GameObject grabbedObject)
        {
            if (_handAnimator != null)
            {
                _handAnimator.SetBool(_holdingItemParamHash, true);
            }
        }

        private void HandleObjectReleased(GameObject releasedObject)
        {
            if (_handAnimator != null)
            {
                _handAnimator.SetBool(_holdingItemParamHash, false);
            }
        }

        #endregion
    }
}
