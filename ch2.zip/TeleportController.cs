using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using NeighboursFromHellVR.Core.Utility;

namespace NeighboursFromHellVR.Player.Locomotion
{
    /// <summary>
    /// Parabolic-arc teleportation. While the aim action is held, samples a
    /// projectile trajectory from the aim origin, draws it via a
    /// <see cref="LineRenderer"/>, validates the landing point against the
    /// teleportable layer mask, and moves the rig there on release.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class TeleportController : MonoBehaviour
    {
        #region Inspector Fields

        [Header("References")]
        [SerializeField] private CharacterController _characterController;
        [SerializeField] private Transform _rigRoot;
        [SerializeField] private Transform _headTransform;
        [SerializeField] private Transform _aimOrigin;
        [SerializeField] private LineRenderer _arcRenderer;
        [SerializeField] private Transform _reticle;

        [Header("Arc Settings")]
        [SerializeField] private LayerMask _teleportableLayers;
        [SerializeField] private float _arcInitialSpeed = 8f;
        [SerializeField] private float _arcGravity = -9.8f;
        [SerializeField, Range(10, 60)] private int _arcSegments = 24;
        [SerializeField] private float _arcTimeStep = 0.05f;

        [Header("Visuals")]
        [SerializeField] private Color _validColor = new Color(0.2f, 1f, 0.4f, 0.9f);
        [SerializeField] private Color _invalidColor = new Color(1f, 0.25f, 0.2f, 0.9f);

        [Header("Haptics")]
        [SerializeField, Range(0f, 1f)] private float _hapticAmplitude = 0.4f;
        [SerializeField] private float _hapticDuration = 0.08f;

        [Header("Input")]
        [SerializeField] private InputActionReference _aimAction;

        #endregion

        #region Private Fields

        private readonly List<Vector3> _arcPoints = new List<Vector3>();
        private bool _isAiming;
        private bool _targetValid;
        private Vector3 _targetPoint;

        #endregion

        #region Events

        /// <summary>Raised immediately after a teleport is performed. Payload: the new world position.</summary>
        public event Action<Vector3> TeleportPerformed;

        #endregion

        #region Properties

        /// <summary>Whether the player is currently aiming a teleport.</summary>
        public bool IsAiming => _isAiming;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            if (_rigRoot == null)
            {
                _rigRoot = transform;
            }

            if (_arcRenderer != null)
            {
                _arcRenderer.positionCount = 0;
                _arcRenderer.enabled = false;
            }

            if (_reticle != null)
            {
                _reticle.gameObject.SetActive(false);
            }
        }

        private void OnEnable()
        {
            if (_aimAction != null && _aimAction.action != null)
            {
                _aimAction.action.started += HandleAimStarted;
                _aimAction.action.canceled += HandleAimCanceled;
                _aimAction.action.Enable();
            }
        }

        private void OnDisable()
        {
            if (_aimAction != null && _aimAction.action != null)
            {
                _aimAction.action.started -= HandleAimStarted;
                _aimAction.action.canceled -= HandleAimCanceled;
            }

            StopAiming();
        }

        private void Update()
        {
            if (_isAiming)
            {
                UpdateArc();
            }
        }

        #endregion

        #region Aim Handling

        private void HandleAimStarted(InputAction.CallbackContext context)
        {
            _isAiming = true;

            if (_arcRenderer != null)
            {
                _arcRenderer.enabled = true;
            }
        }

        private void HandleAimCanceled(InputAction.CallbackContext context)
        {
            bool shouldTeleport = _isAiming && _targetValid;
            Vector3 destination = _targetPoint;

            StopAiming();

            if (shouldTeleport)
            {
                PerformTeleport(destination);
            }
        }

        private void StopAiming()
        {
            _isAiming = false;
            _targetValid = false;

            if (_arcRenderer != null)
            {
                _arcRenderer.enabled = false;
                _arcRenderer.positionCount = 0;
            }

            if (_reticle != null)
            {
                _reticle.gameObject.SetActive(false);
            }
        }

        #endregion

        #region Arc Simulation

        /// <summary>
        /// Samples a fixed-timestep projectile arc from the aim origin,
        /// stopping at the first collision with the teleportable layers
        /// (valid landing) or any other surface (invalid landing).
        /// </summary>
        private void UpdateArc()
        {
            if (_aimOrigin == null)
            {
                return;
            }

            _arcPoints.Clear();

            Vector3 point = _aimOrigin.position;
            Vector3 velocity = _aimOrigin.forward * _arcInitialSpeed;

            _targetValid = false;
            _targetPoint = point;

            for (int i = 0; i < _arcSegments; i++)
            {
                _arcPoints.Add(point);

                Vector3 nextPoint = point + (velocity * _arcTimeStep);
                nextPoint.y += 0.5f * _arcGravity * (_arcTimeStep * _arcTimeStep);
                velocity.y += _arcGravity * _arcTimeStep;

                if (Physics.Linecast(point, nextPoint, out RaycastHit hit, ~0, QueryTriggerInteraction.Ignore))
                {
                    _arcPoints.Add(hit.point);
                    _targetPoint = hit.point;
                    _targetValid = IsOnTeleportableLayer(hit.collider.gameObject.layer);
                    break;
                }

                point = nextPoint;
            }

            DrawArc();
            UpdateReticle();
        }

        private bool IsOnTeleportableLayer(int layer)
        {
            return (_teleportableLayers.value & (1 << layer)) != 0;
        }

        private void DrawArc()
        {
            if (_arcRenderer == null)
            {
                return;
            }

            _arcRenderer.positionCount = _arcPoints.Count;
            _arcRenderer.SetPositions(_arcPoints.ToArray());

            Color color = _targetValid ? _validColor : _invalidColor;
            _arcRenderer.startColor = color;
            _arcRenderer.endColor = color;
        }

        private void UpdateReticle()
        {
            if (_reticle == null)
            {
                return;
            }

            _reticle.gameObject.SetActive(_targetValid);

            if (_targetValid)
            {
                _reticle.position = _targetPoint;
            }
        }

        #endregion

        #region Teleport Execution

        /// <summary>
        /// Moves the rig so the landing point aligns with the player's feet,
        /// preserving the player's current horizontal offset from the
        /// headset within their tracked play space.
        /// </summary>
        private void PerformTeleport(Vector3 targetPoint)
        {
            Vector3 headOffset = _headTransform != null
                ? new Vector3(_headTransform.position.x - _rigRoot.position.x, 0f, _headTransform.position.z - _rigRoot.position.z)
                : Vector3.zero;

            bool hadController = _characterController != null && _characterController.enabled;
            if (hadController)
            {
                _characterController.enabled = false;
            }

            _rigRoot.position = targetPoint - headOffset;

            if (hadController)
            {
                _characterController.enabled = true;
            }

            TeleportPerformed?.Invoke(_rigRoot.position);

            if (_aimOrigin != null)
            {
                HapticFeedback.Send(_aimOrigin, _hapticAmplitude, _hapticDuration);
            }
        }

        #endregion
    }
}
