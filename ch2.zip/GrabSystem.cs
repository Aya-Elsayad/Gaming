using System;
using System.Collections.Generic;
using UnityEngine;
using NeighboursFromHellVR.Core.Interfaces;

namespace NeighboursFromHellVR.Player
{
    /// <summary>
    /// Which hand a grab event originated from. Used throughout the grab
    /// event payloads so listeners (Inventory, UI, ObjectiveManager) don't
    /// need to know about ObjectGrabber internals.
    /// </summary>
    public enum Hand
    {
        Left,
        Right
    }

    /// <summary>
    /// Player-level coordinator sitting above the two per-hand
    /// <see cref="ObjectGrabber"/> components. Responsibilities:
    /// - Exposes a single place to query "what is the player holding".
    /// - Detects when both hands grab the same Rigidbody (two-handed hold),
    ///   which some large prank items (Chair Trap, Water Bucket) require.
    /// - Re-broadcasts per-hand grab/release events with the acting hand
    ///   identified, since downstream systems care which hand did what
    ///   (e.g. Inventory storing to a hand-specific slot).
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class GrabSystem : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Hand References")]
        [SerializeField] private ObjectGrabber _leftHandGrabber;
        [SerializeField] private ObjectGrabber _rightHandGrabber;

        #endregion

        #region Private Fields

        private readonly Dictionary<Hand, GameObject> _heldByHand = new Dictionary<Hand, GameObject>
        {
            { Hand.Left, null },
            { Hand.Right, null }
        };

        #endregion

        #region Events

        /// <summary>Raised when either hand grabs an object. Payload: the hand and the grabbed GameObject.</summary>
        public event Action<Hand, GameObject> HandGrabbed;

        /// <summary>Raised when either hand releases an object. Payload: the hand and the released GameObject.</summary>
        public event Action<Hand, GameObject> HandReleased;

        /// <summary>Raised when both hands are found to be holding the same Rigidbody (two-handed grip established).</summary>
        public event Action<GameObject> TwoHandedGripEstablished;

        /// <summary>Raised when a two-handed grip is broken because one hand released.</summary>
        public event Action<GameObject> TwoHandedGripBroken;

        #endregion

        #region Properties

        /// <summary>Whether any hand is currently holding something.</summary>
        public bool IsHoldingAnything => _heldByHand[Hand.Left] != null || _heldByHand[Hand.Right] != null;

        /// <summary>Whether both hands are currently gripping the same object.</summary>
        public bool IsTwoHandedGripActive { get; private set; }

        #endregion

        #region Unity Lifecycle

        private void OnEnable()
        {
            if (_leftHandGrabber != null)
            {
                _leftHandGrabber.ObjectGrabbed += HandleLeftGrabbed;
                _leftHandGrabber.ObjectReleased += HandleLeftReleased;
            }

            if (_rightHandGrabber != null)
            {
                _rightHandGrabber.ObjectGrabbed += HandleRightGrabbed;
                _rightHandGrabber.ObjectReleased += HandleRightReleased;
            }
        }

        private void OnDisable()
        {
            if (_leftHandGrabber != null)
            {
                _leftHandGrabber.ObjectGrabbed -= HandleLeftGrabbed;
                _leftHandGrabber.ObjectReleased -= HandleLeftReleased;
            }

            if (_rightHandGrabber != null)
            {
                _rightHandGrabber.ObjectGrabbed -= HandleRightGrabbed;
                _rightHandGrabber.ObjectReleased -= HandleRightReleased;
            }
        }

        #endregion

        #region Grab / Release Handling

        private void HandleLeftGrabbed(GameObject grabbedObject) => HandleGrabbed(Hand.Left, grabbedObject);
        private void HandleLeftReleased(GameObject releasedObject) => HandleReleased(Hand.Left, releasedObject);
        private void HandleRightGrabbed(GameObject grabbedObject) => HandleGrabbed(Hand.Right, grabbedObject);
        private void HandleRightReleased(GameObject releasedObject) => HandleReleased(Hand.Right, releasedObject);

        private void HandleGrabbed(Hand hand, GameObject grabbedObject)
        {
            _heldByHand[hand] = grabbedObject;
            HandGrabbed?.Invoke(hand, grabbedObject);

            CheckForTwoHandedGrip();
        }

        private void HandleReleased(Hand hand, GameObject releasedObject)
        {
            bool wasTwoHanded = IsTwoHandedGripActive;
            GameObject previouslyHeld = _heldByHand[hand];

            _heldByHand[hand] = null;
            HandReleased?.Invoke(hand, releasedObject);

            if (wasTwoHanded)
            {
                IsTwoHandedGripActive = false;
                TwoHandedGripBroken?.Invoke(previouslyHeld != null ? previouslyHeld : releasedObject);
            }
        }

        /// <summary>
        /// Checks whether both hands are now holding the same underlying
        /// Rigidbody (i.e. two colliders belonging to one physics body,
        /// such as either end of a long Chair Trap prop).
        /// </summary>
        private void CheckForTwoHandedGrip()
        {
            GameObject left = _heldByHand[Hand.Left];
            GameObject right = _heldByHand[Hand.Right];

            if (left == null || right == null)
            {
                return;
            }

            if (!left.TryGetComponent(out Rigidbody leftBody) || !right.TryGetComponent(out Rigidbody rightBody))
            {
                return;
            }

            if (leftBody != rightBody)
            {
                return;
            }

            if (IsTwoHandedGripActive)
            {
                return;
            }

            IsTwoHandedGripActive = true;
            TwoHandedGripEstablished?.Invoke(left);
        }

        #endregion

        #region Queries

        /// <summary>Returns the GameObject currently held by the given hand, or null if empty.</summary>
        public GameObject GetHeldObject(Hand hand)
        {
            return _heldByHand[hand];
        }

        /// <summary>Returns the IGrabbable currently held by the given hand, or null if empty or not grabbable.</summary>
        public IGrabbable GetHeldGrabbable(Hand hand)
        {
            GameObject held = _heldByHand[hand];
            if (held == null)
            {
                return null;
            }

            held.TryGetComponent(out IGrabbable grabbable);
            return grabbable;
        }

        /// <summary>Forces both hands to release whatever they're holding, e.g. on death or cutscene start.</summary>
        public void ReleaseAll()
        {
            _leftHandGrabber?.ReleaseHeldObject();
            _rightHandGrabber?.ReleaseHeldObject();
        }

        #endregion
    }
}
