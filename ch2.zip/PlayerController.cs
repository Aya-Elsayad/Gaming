using System;
using UnityEngine;
using NeighboursFromHellVR.Player.Locomotion;

namespace NeighboursFromHellVR.Player
{
    /// <summary>
    /// Locomotion mode the player is currently using to move through the level.
    /// </summary>
    public enum LocomotionMode
    {
        Smooth,
        Teleport
    }

    /// <summary>
    /// Master player coordinator. Owns the <see cref="CharacterController"/>,
    /// gravity, and head-tracked height/crouch calibration, and toggles
    /// which locomotion component (<see cref="SmoothLocomotion"/> or
    /// <see cref="TeleportController"/>) is active. <see cref="SnapTurn"/>
    /// runs independently of locomotion mode since it applies in both.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(CharacterController))]
    public sealed class PlayerController : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Rig References")]
        [SerializeField] private Transform _headTransform;

        [Header("Locomotion Components")]
        [SerializeField] private SmoothLocomotion _smoothLocomotion;
        [SerializeField] private TeleportController _teleportController;
        [SerializeField] private SnapTurn _snapTurn;

        [Header("Locomotion Mode")]
        [SerializeField] private LocomotionMode _startingMode = LocomotionMode.Smooth;

        [Header("Gravity & Height")]
        [SerializeField] private float _gravity = -9.81f;
        [SerializeField] private float _minControllerHeight = 0.5f;
        [SerializeField] private float _crouchHeightThreshold = 1.0f;

        #endregion

        #region Private Fields

        private CharacterController _characterController;
        private float _verticalVelocity;

        #endregion

        #region Events

        /// <summary>Raised whenever the active locomotion mode changes.</summary>
        public event Action<LocomotionMode> LocomotionModeChanged;

        /// <summary>Raised every frame with the current crouch state after height sync.</summary>
        public event Action<bool> CrouchStateChanged;

        #endregion

        #region Properties

        /// <summary>The locomotion mode currently active.</summary>
        public LocomotionMode CurrentMode { get; private set; }

        /// <summary>Whether the player's tracked head height is below the crouch threshold.</summary>
        public bool IsCrouched { get; private set; }

        /// <summary>The CharacterController driving this player's collision volume.</summary>
        public CharacterController Controller => _characterController;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _characterController = GetComponent<CharacterController>();
            CurrentMode = _startingMode;
        }

        private void OnEnable()
        {
            if (_teleportController != null)
            {
                _teleportController.TeleportPerformed += HandleTeleportPerformed;
            }

            ApplyLocomotionModeState();
        }

        private void OnDisable()
        {
            if (_teleportController != null)
            {
                _teleportController.TeleportPerformed -= HandleTeleportPerformed;
            }
        }

        private void Update()
        {
            SyncControllerHeightWithHead();
            ApplyGravity();
        }

        #endregion

        #region Gravity & Height Calibration

        /// <summary>
        /// Applies gravity each frame, resetting vertical velocity when
        /// grounded so the player doesn't accumulate fall speed on flat ground.
        /// </summary>
        private void ApplyGravity()
        {
            if (_characterController.isGrounded && _verticalVelocity < 0f)
            {
                _verticalVelocity = -2f;
            }

            _verticalVelocity += _gravity * Time.deltaTime;
            _characterController.Move(new Vector3(0f, _verticalVelocity * Time.deltaTime, 0f));
        }

        /// <summary>
        /// Keeps the CharacterController's height/center matched to the
        /// player's real, physically tracked headset height, and propagates
        /// crouch state to the active smooth-locomotion component.
        /// </summary>
        private void SyncControllerHeightWithHead()
        {
            if (_headTransform == null)
            {
                return;
            }

            float headHeight = Mathf.Max(_minControllerHeight, _headTransform.localPosition.y);

            _characterController.height = headHeight;
            _characterController.center = new Vector3(
                _headTransform.localPosition.x,
                headHeight / 2f,
                _headTransform.localPosition.z);

            bool wasCrouched = IsCrouched;
            IsCrouched = headHeight < _crouchHeightThreshold;

            if (_smoothLocomotion != null)
            {
                _smoothLocomotion.IsCrouched = IsCrouched;
            }

            if (IsCrouched != wasCrouched)
            {
                CrouchStateChanged?.Invoke(IsCrouched);
            }
        }

        #endregion

        #region Locomotion Mode

        /// <summary>
        /// Switches the active locomotion mode and enables/disables the
        /// corresponding component. Public so the Pause Menu / accessibility
        /// settings UI can drive this directly.
        /// </summary>
        public void SetLocomotionMode(LocomotionMode mode)
        {
            if (mode == CurrentMode)
            {
                return;
            }

            CurrentMode = mode;
            ApplyLocomotionModeState();
            LocomotionModeChanged?.Invoke(CurrentMode);
        }

        private void ApplyLocomotionModeState()
        {
            if (_smoothLocomotion != null)
            {
                _smoothLocomotion.enabled = CurrentMode == LocomotionMode.Smooth;
            }

            if (_teleportController != null)
            {
                _teleportController.enabled = CurrentMode == LocomotionMode.Teleport;
            }
        }

        #endregion

        #region Event Relays

        private void HandleTeleportPerformed(Vector3 newPosition)
        {
            // Hook point for future systems (footstep dust VFX suppression,
            // AI noise events, checkpoint tracking) without coupling
            // TeleportController to those systems directly.
        }

        #endregion
    }
}
