using UnityEngine;
using UnityEngine.InputSystem;

namespace NeighboursFromHellVR.Player.Locomotion
{
    /// <summary>
    /// Continuous joystick locomotion relative to the tracked headset's yaw.
    /// Driven externally by <see cref="PlayerController"/>, which enables
    /// this component only while <c>LocomotionMode.Smooth</c> is active.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SmoothLocomotion : MonoBehaviour
    {
        #region Inspector Fields

        [Header("References")]
        [SerializeField] private CharacterController _characterController;
        [SerializeField] private Transform _headTransform;

        [Header("Movement")]
        [SerializeField] private float _moveSpeed = 2.5f;
        [SerializeField] private float _crouchSpeedMultiplier = 0.6f;
        [SerializeField] private float _inputDeadzone = 0.05f;

        [Header("Input")]
        [SerializeField] private InputActionReference _moveAction;

        #endregion

        #region Properties

        /// <summary>Whether the player is currently crouched, set externally by PlayerController.</summary>
        public bool IsCrouched { get; set; }

        /// <summary>Current world-space move velocity applied this frame (for audio/animation systems).</summary>
        public Vector3 CurrentVelocity { get; private set; }

        #endregion

        #region Unity Lifecycle

        private void OnEnable()
        {
            if (_moveAction != null && _moveAction.action != null)
            {
                _moveAction.action.Enable();
            }
        }

        private void Update()
        {
            Tick();
        }

        #endregion

        #region Locomotion

        /// <summary>
        /// Reads the move axis and advances the CharacterController relative
        /// to the headset's flattened forward/right vectors.
        /// </summary>
        private void Tick()
        {
            if (_characterController == null || _moveAction == null || _moveAction.action == null)
            {
                CurrentVelocity = Vector3.zero;
                return;
            }

            Vector2 input = _moveAction.action.ReadValue<Vector2>();
            if (input.sqrMagnitude < _inputDeadzone * _inputDeadzone)
            {
                CurrentVelocity = Vector3.zero;
                return;
            }

            Vector3 headForward = _headTransform != null ? _headTransform.forward : transform.forward;
            Vector3 headRight = _headTransform != null ? _headTransform.right : transform.right;
            headForward.y = 0f;
            headRight.y = 0f;
            headForward.Normalize();
            headRight.Normalize();

            Vector3 moveDirection = (headForward * input.y) + (headRight * input.x);
            float speed = _moveSpeed * (IsCrouched ? _crouchSpeedMultiplier : 1f);

            Vector3 delta = moveDirection * speed * Time.deltaTime;
            _characterController.Move(delta);

            CurrentVelocity = Time.deltaTime > 0f ? delta / Time.deltaTime : Vector3.zero;
        }

        #endregion
    }
}
