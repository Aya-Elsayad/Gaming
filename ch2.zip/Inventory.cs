using System;
using UnityEngine;
using NeighboursFromHellVR.Items;

namespace NeighboursFromHellVR.Player
{
    /// <summary>
    /// Fixed-size slot inventory for prank items. Storing an item disables
    /// its physics/rendering and parents it to an internal holder so it
    /// stops existing "in the world" without destroying it; retrieving it
    /// re-enables physics and hands it back to the requesting hand via the
    /// normal <see cref="Item.OnGrab"/> path, so grabbed-from-inventory
    /// items behave identically to grabbed-from-world items.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class Inventory : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Capacity")]
        [Tooltip("Maximum number of items the player can carry at once.")]
        [SerializeField, Range(1, 8)] private int _slotCount = 4;

        [Header("Storage")]
        [Tooltip("Transform items are parented to and hidden at while stored.")]
        [SerializeField] private Transform _storageHolder;

        #endregion

        #region Private Fields

        private Item[] _slots;

        #endregion

        #region Events

        /// <summary>Raised when an item is added to a slot. Payload: slot index, item.</summary>
        public event Action<int, Item> ItemAdded;

        /// <summary>Raised when an item is removed from a slot. Payload: slot index, item that was removed.</summary>
        public event Action<int, Item> ItemRemoved;

        #endregion

        #region Properties

        /// <summary>Total number of slots available.</summary>
        public int SlotCount => _slotCount;

        /// <summary>Number of currently occupied slots.</summary>
        public int OccupiedSlotCount
        {
            get
            {
                int count = 0;
                for (int i = 0; i < _slots.Length; i++)
                {
                    if (_slots[i] != null)
                    {
                        count++;
                    }
                }

                return count;
            }
        }

        /// <summary>Whether the inventory has at least one free slot.</summary>
        public bool HasFreeSlot => OccupiedSlotCount < _slotCount;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _slots = new Item[_slotCount];

            if (_storageHolder == null)
            {
                GameObject holder = new GameObject("InventoryStorageHolder");
                holder.transform.SetParent(transform, false);
                _storageHolder = holder.transform;
            }
        }

        #endregion

        #region Add / Remove

        /// <summary>
        /// Attempts to store the given item in the first free slot. The item
        /// must not currently be grabbed (release it from the hand first).
        /// </summary>
        /// <param name="item">The item to store.</param>
        /// <param name="slotIndex">The slot the item was stored in, or -1 on failure.</param>
        /// <returns>True if the item was stored.</returns>
        public bool TryAddItem(Item item, out int slotIndex)
        {
            slotIndex = -1;

            if (item == null || item.IsGrabbed || item.IsConsumed)
            {
                return false;
            }

            for (int i = 0; i < _slots.Length; i++)
            {
                if (_slots[i] != null)
                {
                    continue;
                }

                _slots[i] = item;
                slotIndex = i;

                StoreItemPhysically(item);

                ItemAdded?.Invoke(i, item);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Removes and returns the item from the given slot without
        /// re-attaching it to a hand. Use <see cref="RetrieveToHand"/> to
        /// remove and immediately equip in one step.
        /// </summary>
        public bool TryRemoveItem(int slotIndex, out Item removedItem)
        {
            removedItem = null;

            if (!IsValidSlot(slotIndex) || _slots[slotIndex] == null)
            {
                return false;
            }

            removedItem = _slots[slotIndex];
            _slots[slotIndex] = null;

            ItemRemoved?.Invoke(slotIndex, removedItem);
            return true;
        }

        /// <summary>
        /// Removes the item from the given slot and immediately grabs it
        /// with the given hand transform, restoring physics/rendering.
        /// </summary>
        /// <param name="slotIndex">Slot to retrieve from.</param>
        /// <param name="handTransform">Hand transform to attach the item to.</param>
        /// <returns>The retrieved item, or null if the slot was empty/invalid.</returns>
        public Item RetrieveToHand(int slotIndex, Transform handTransform)
        {
            if (!TryRemoveItem(slotIndex, out Item item))
            {
                return null;
            }

            RestoreItemPhysically(item);
            item.OnGrab(handTransform);
            return item;
        }

        /// <summary>Returns the item stored in the given slot without removing it, or null if empty.</summary>
        public Item PeekSlot(int slotIndex)
        {
            return IsValidSlot(slotIndex) ? _slots[slotIndex] : null;
        }

        #endregion

        #region Physical Storage Helpers

        /// <summary>
        /// Disables the physical presence of an item while it's stowed:
        /// stops physics simulation, disables colliders/renderers, and
        /// parents it under the hidden storage holder.
        /// </summary>
        private void StoreItemPhysically(Item item)
        {
            item.transform.SetParent(_storageHolder, false);
            item.transform.localPosition = Vector3.zero;
            item.transform.localRotation = Quaternion.identity;

            if (item.GrabbableRigidbody != null)
            {
                item.GrabbableRigidbody.isKinematic = true;
                item.GrabbableRigidbody.useGravity = false;
            }

            SetItemVisualsAndCollision(item, false);
        }

        /// <summary>
        /// Re-enables physics/rendering for an item as it leaves storage,
        /// unparenting it back into the world so it can follow the hand.
        /// </summary>
        private void RestoreItemPhysically(Item item)
        {
            item.transform.SetParent(null);

            if (item.GrabbableRigidbody != null)
            {
                item.GrabbableRigidbody.isKinematic = false;
            }

            SetItemVisualsAndCollision(item, true);
        }

        private static void SetItemVisualsAndCollision(Item item, bool enabled)
        {
            Renderer[] renderers = item.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < renderers.Length; i++)
            {
                renderers[i].enabled = enabled;
            }

            Collider[] colliders = item.GetComponentsInChildren<Collider>(true);
            for (int i = 0; i < colliders.Length; i++)
            {
                colliders[i].enabled = enabled;
            }
        }

        #endregion

        #region Validation

        private bool IsValidSlot(int slotIndex)
        {
            return _slots != null && slotIndex >= 0 && slotIndex < _slots.Length;
        }

        #endregion
    }
}
