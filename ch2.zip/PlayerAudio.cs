using UnityEngine;
using NeighboursFromHellVR.Player.Locomotion;

namespace NeighboursFromHellVR.Player
{
    /// <summary>
    /// Drives player-originated audio: footsteps timed to movement speed
    /// (which the enemy AI's hearing radius reacts to in Chapter 3), and
    /// stress breathing while caught. Footstep volume directly represents
    /// how much noise the player is making, since noise is a core stealth
    /// mechanic in Neighbours From Hell VR.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(AudioSource))]
    public sealed class PlayerAudio : MonoBehaviour
    {
        #region Inspector Fields

        [Header("References")]
        [SerializeField] private SmoothLocomotion _smoothLocomotion;
        [SerializeField] private PlayerHealth _playerHealth;

        [Header("Footsteps")]
        [SerializeField] private AudioClip[] _footstepClips;
        [SerializeField] private float _footstepInterval = 0.5f;
        [SerializeField] private float _crouchFootstepIntervalMultiplier = 1.6f;
        [SerializeField] private float _minSpeedToStep = 0.2f;
        [SerializeField, Range(0f, 1f)] private float _walkVolume = 0.6f;
        [SerializeField, Range(0f, 1f)] private float _crouchVolume = 0.2f;

        [Header("Breathing")]
        [SerializeField] private AudioClip _stressBreathingClip;
        [SerializeField, Range(0f, 1f)] private float _breathingVolume = 0.5f;

        #endregion

        #region Private Fields

        private AudioSource _audioSource;
        private AudioSource _breathingSource;
        private float _footstepTimer;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _audioSource = GetComponent<AudioSource>();
            _audioSource.playOnAwake = false;
            _audioSource.loop = false;

            _breathingSource = gameObject.AddComponent<AudioSource>();
            _breathingSource.playOnAwake = false;
            _breathingSource.loop = true;
            _breathingSource.volume = 0f;
            _breathingSource.clip = _stressBreathingClip;
        }

        private void OnEnable()
        {
            if (_playerHealth != null)
            {
                _playerHealth.Caught += HandleCaught;
            }
        }

        private void OnDisable()
        {
            if (_playerHealth != null)
            {
                _playerHealth.Caught -= HandleCaught;
            }
        }

        private void Update()
        {
            TickFootsteps();
            TickBreathing();
        }

        #endregion

        #region Footsteps

        /// <summary>
        /// Plays a randomized footstep clip at an interval that scales with
        /// crouch state, only while the player is actually moving.
        /// </summary>
        private void TickFootsteps()
        {
            if (_smoothLocomotion == null || !_smoothLocomotion.enabled || _footstepClips == null || _footstepClips.Length == 0)
            {
                return;
            }

            float speed = _smoothLocomotion.CurrentVelocity.magnitude;
            if (speed < _minSpeedToStep)
            {
                _footstepTimer = 0f;
                return;
            }

            _footstepTimer -= Time.deltaTime;
            if (_footstepTimer > 0f)
            {
                return;
            }

            bool isCrouched = _smoothLocomotion.IsCrouched;
            float interval = _footstepInterval * (isCrouched ? _crouchFootstepIntervalMultiplier : 1f);
            _footstepTimer = interval;

            AudioClip clip = _footstepClips[Random.Range(0, _footstepClips.Length)];
            float volume = isCrouched ? _crouchVolume : _walkVolume;

            _audioSource.PlayOneShot(clip, volume);
        }

        #endregion

        #region Breathing

        /// <summary>Fades stress-breathing audio in while caught, out otherwise.</summary>
        private void TickBreathing()
        {
            if (_breathingSource.clip == null)
            {
                return;
            }

            bool shouldBreathe = _playerHealth != null && _playerHealth.IsCaught;

            if (shouldBreathe && !_breathingSource.isPlaying)
            {
                _breathingSource.Play();
            }

            float targetVolume = shouldBreathe ? _breathingVolume : 0f;
            _breathingSource.volume = Mathf.MoveTowards(_breathingSource.volume, targetVolume, Time.deltaTime);

            if (!shouldBreathe && _breathingSource.volume <= 0f && _breathingSource.isPlaying)
            {
                _breathingSource.Stop();
            }
        }

        private void HandleCaught(int remainingLives)
        {
            _footstepTimer = 0f;
        }

        #endregion
    }
}
