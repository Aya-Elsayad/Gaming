using System;
using UnityEngine;

namespace NeighboursFromHellVR.Player
{
    /// <summary>
    /// Tracks the player's life/caught state for the stealth loop. Neighbours
    /// From Hell VR isn't combat-based, so "health" here represents
    /// remaining attempts before a hard level restart (Mr. Rottweiler
    /// catching the player), rather than a damage/HP bar.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class PlayerHealth : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Lives")]
        [SerializeField, Range(1, 10)] private int _maxLives = 3;

        [Header("Caught Recovery")]
        [Tooltip("Seconds the player is invulnerable to being caught again immediately after a recovery.")]
        [SerializeField] private float _postRecoveryInvulnerabilitySeconds = 2f;

        #endregion

        #region Private Fields

        private int _currentLives;
        private bool _isInvulnerable;
        private float _invulnerabilityTimer;
        private bool _isCaught;

        #endregion

        #region Events

        /// <summary>Raised when the player is caught by the enemy. Payload: remaining lives.</summary>
        public event Action<int> Caught;

        /// <summary>Raised when lives reach zero and the level must restart.</summary>
        public event Action GameOver;

        /// <summary>Raised when lives are restored to full, e.g. on level start.</summary>
        public event Action<int> LivesReset;

        #endregion

        #region Properties

        /// <summary>Current remaining lives.</summary>
        public int CurrentLives => _currentLives;

        /// <summary>Maximum lives configured for this session.</summary>
        public int MaxLives => _maxLives;

        /// <summary>Whether the player is currently in a caught/invulnerable grace period.</summary>
        public bool IsCaught => _isCaught;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _currentLives = _maxLives;
        }

        private void Update()
        {
            if (_isInvulnerable)
            {
                _invulnerabilityTimer -= Time.deltaTime;
                if (_invulnerabilityTimer <= 0f)
                {
                    _isInvulnerable = false;
                    _isCaught = false;
                }
            }
        }

        #endregion

        #region Public API

        /// <summary>
        /// Called by the enemy AI's "Caught Player" state when line-of-sight
        /// detection completes. Decrements a life, raises <see cref="Caught"/>,
        /// and raises <see cref="GameOver"/> if no lives remain.
        /// </summary>
        public void RegisterCaught()
        {
            if (_isInvulnerable || _isCaught)
            {
                return;
            }

            _currentLives = Mathf.Max(0, _currentLives - 1);
            _isCaught = true;
            _isInvulnerable = true;
            _invulnerabilityTimer = _postRecoveryInvulnerabilitySeconds;

            Caught?.Invoke(_currentLives);

            if (_currentLives <= 0)
            {
                GameOver?.Invoke();
            }
        }

        /// <summary>Restores lives to maximum, typically called by LevelManager on level (re)start.</summary>
        public void ResetLives()
        {
            _currentLives = _maxLives;
            _isCaught = false;
            _isInvulnerable = false;
            _invulnerabilityTimer = 0f;

            LivesReset?.Invoke(_currentLives);
        }

        #endregion
    }
}
