using System;
using UnityEngine;
using UnityEngine.InputSystem;
using NeighboursFromHellVR.Core.Utility;

namespace NeighboursFromHellVR.Player.Locomotion
{
    /// <summary>
    /// Discrete snap-turn rotation around the tracked headset position,
    /// reading the horizontal axis of the turn action and applying a fixed
    /// angle increment with a cooldown to prevent multi-triggering.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SnapTurn : MonoBehaviour
    {
        #region Inspector Fields

        [Header("References")]
        [SerializeField] private Transform _rigRoot;
        [SerializeField] private Transform _headTransform;
        [SerializeField] private Transform _hapticTarget;

        [Header("Turn Settings")]
        [SerializeField] private float _turnAngleDegrees = 45f;
        [SerializeField] private float _deadzone = 0.6f;
        [SerializeField] private float _cooldownSeconds = 0.25f;

        [Header("Haptics")]
        [SerializeField, Range(0f, 1f)] private float _hapticAmplitude = 0.25f;
        [SerializeField] private float _hapticDuration = 0.05f;

        [Header("Input")]
        [SerializeField] private InputActionReference _turnAction;

        #endregion

        #region Private Fields

        private float _cooldownTimer;

        #endregion

        #region Events

        /// <summary>Raised each time a snap turn is performed. Payload: signed degrees turned.</summary>
        public event Action<float> Turned;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            if (_rigRoot == null)
            {
                _rigRoot = transform;
            }
        }

        private void OnEnable()
        {
            if (_turnAction != null && _turnAction.action != null)
            {
                _turnAction.action.performed += HandleTurnPerformed;
                _turnAction.action.Enable();
            }
        }

        private void OnDisable()
        {
            if (_turnAction != null && _turnAction.action != null)
            {
                _turnAction.action.performed -= HandleTurnPerformed;
            }
        }

        private void Update()
        {
            if (_cooldownTimer > 0f)
            {
                _cooldownTimer -= Time.deltaTime;
            }
        }

        #endregion

        #region Turn Handling

        private void HandleTurnPerformed(InputAction.CallbackContext context)
        {
            if (_cooldownTimer > 0f)
            {
                return;
            }

            Vector2 input = context.ReadValue<Vector2>();
            if (Mathf.Abs(input.x) < _deadzone)
            {
                return;
            }

            float direction = Mathf.Sign(input.x);
            float turnAmount = direction * _turnAngleDegrees;
            Vector3 pivot = _headTransform != null ? _headTransform.position : _rigRoot.position;

            _rigRoot.RotateAround(pivot, Vector3.up, turnAmount);

            _cooldownTimer = _cooldownSeconds;
            Turned?.Invoke(turnAmount);

            if (_hapticTarget != null)
            {
                HapticFeedback.Send(_hapticTarget, _hapticAmplitude, _hapticDuration);
            }
        }

        #endregion
    }
}
