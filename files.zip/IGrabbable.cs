using UnityEngine;

namespace NeighboursFromHellVR.Core.Interfaces
{
    /// <summary>
    /// Contract for objects that can be physically picked up, carried,
    /// and thrown by the player's VR hands (e.g. prank items, doors' handles,
    /// kitchen utensils). Distinct from IInteractable because a grabbable
    /// object also needs physics hand-off logic (rigidbody, kinematic toggling,
    /// throw velocity capture).
    /// </summary>
    public interface IGrabbable
    {
        /// <summary>The Rigidbody that will be controlled while grabbed.</summary>
        Rigidbody GrabbableRigidbody { get; }

        /// <summary>Whether the object is currently held by a hand.</summary>
        bool IsGrabbed { get; }

        /// <summary>
        /// Called the instant a hand grabs this object.
        /// Implementations should switch the Rigidbody to kinematic/tracked mode.
        /// </summary>
        /// <param name="grabber">The hand/controller transform that grabbed the object.</param>
        void OnGrab(Transform grabber);

        /// <summary>
        /// Called the instant a hand releases this object.
        /// </summary>
        /// <param name="releaseVelocity">Linear velocity to apply on release, computed from hand motion.</param>
        /// <param name="releaseAngularVelocity">Angular velocity to apply on release.</param>
        void OnRelease(Vector3 releaseVelocity, Vector3 releaseAngularVelocity);

        /// <summary>
        /// Called every frame while grabbed, allowing the object to follow
        /// the hand's target pose (used for attach-point offset correction).
        /// </summary>
        /// <param name="targetPosition">World position the object should follow.</param>
        /// <param name="targetRotation">World rotation the object should follow.</param>
        void OnGrabMove(Vector3 targetPosition, Quaternion targetRotation);
    }
}
