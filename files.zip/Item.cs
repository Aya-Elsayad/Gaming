using System;
using UnityEngine;
using NeighboursFromHellVR.Core.Interfaces;

namespace NeighboursFromHellVR.Items
{
    /// <summary>
    /// Abstract base class for every pickupable item in the game
    /// (Banana, Soap, Glue, Coffee, Tea, Lantern, Firecracker, ChairTrap, ...).
    /// Provides shared grab physics, inventory metadata, and the hook
    /// derived classes use to define their unique prank behaviour.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public abstract class Item : MonoBehaviour, IGrabbable, IInteractable
    {
        #region Inspector Fields

        [Header("Item Identity")]
        [Tooltip("Unique ID used for save data and inventory lookups.")]
        [SerializeField] private string _itemId;

        [Tooltip("Display name shown in inventory UI and interaction prompts.")]
        [SerializeField] private string _displayName;

        [Tooltip("Icon shown in the inventory UI.")]
        [SerializeField] private Sprite _icon;

        [Header("Grab Settings")]
        [Tooltip("Local offset applied when attached to a hand, for natural grip pose.")]
        [SerializeField] private Vector3 _grabPositionOffset;

        [Tooltip("Local rotation offset applied when attached to a hand.")]
        [SerializeField] private Vector3 _grabRotationOffsetEuler;

        [Tooltip("Follow speed used to lerp position/rotation toward the hand target while grabbed.")]
        [SerializeField] private float _followSpeed = 25f;

        [Header("Audio & Feedback")]
        [Tooltip("Sound played when the item is picked up.")]
        [SerializeField] private AudioClip _pickupSound;

        [Tooltip("Haptic amplitude (0-1) applied to the grabbing controller on pickup.")]
        [SerializeField, Range(0f, 1f)] private float _pickupHapticAmplitude = 0.3f;

        [Tooltip("Haptic duration in seconds applied on pickup.")]
        [SerializeField] private float _pickupHapticDuration = 0.05f;

        #endregion

        #region Private Fields

        private Rigidbody _rigidbody;
        private Transform _grabber;
        private bool _isGrabbed;
        private AudioSource _audioSource;

        #endregion

        #region Events

        /// <summary>Raised when this item is picked up. Payload: this item.</summary>
        public event Action<Item> ItemPickedUp;

        /// <summary>Raised when this item is dropped or thrown. Payload: this item.</summary>
        public event Action<Item> ItemDropped;

        /// <summary>Raised when this item is consumed/used up (e.g. armed at a prank slot). Payload: this item.</summary>
        public event Action<Item> ItemConsumed;

        #endregion

        #region Properties

        /// <summary>Unique identifier for save/inventory systems.</summary>
        public string ItemId => _itemId;

        /// <summary>Name shown in UI.</summary>
        public string DisplayName => _displayName;

        /// <summary>Icon shown in UI.</summary>
        public Sprite Icon => _icon;

        /// <inheritdoc />
        public Rigidbody GrabbableRigidbody => _rigidbody;

        /// <inheritdoc />
        public bool IsGrabbed => _isGrabbed;

        /// <summary>Whether this item has already been consumed (armed/used) and should be removed from play.</summary>
        public bool IsConsumed { get; private set; }

        /// <inheritdoc />
        public string InteractionPrompt => $"Pick Up {_displayName}";

        /// <inheritdoc />
        public virtual bool CanInteract => !_isGrabbed && !IsConsumed;

        #endregion

        #region Unity Lifecycle

        protected virtual void Awake()
        {
            _rigidbody = GetComponent<Rigidbody>();
            _audioSource = GetComponent<AudioSource>();
        }

        protected virtual void FixedUpdate()
        {
            if (!_isGrabbed || _grabber == null)
            {
                return;
            }

            Vector3 targetPosition = _grabber.TransformPoint(_grabPositionOffset);
            Quaternion targetRotation = _grabber.rotation * Quaternion.Euler(_grabRotationOffsetEuler);

            _rigidbody.MovePosition(Vector3.Lerp(_rigidbody.position, targetPosition, _followSpeed * Time.fixedDeltaTime));
            _rigidbody.MoveRotation(Quaternion.Slerp(_rigidbody.rotation, targetRotation, _followSpeed * Time.fixedDeltaTime));
        }

        #endregion

        #region IGrabbable Implementation

        /// <inheritdoc />
        public virtual void OnGrab(Transform grabber)
        {
            _grabber = grabber;
            _isGrabbed = true;

            _rigidbody.useGravity = false;
            _rigidbody.isKinematic = false;
            _rigidbody.interpolation = RigidbodyInterpolation.Interpolate;

            PlaySound(_pickupSound);
            RequestHaptics(grabber, _pickupHapticAmplitude, _pickupHapticDuration);

            ItemPickedUp?.Invoke(this);
        }

        /// <inheritdoc />
        public virtual void OnRelease(Vector3 releaseVelocity, Vector3 releaseAngularVelocity)
        {
            _isGrabbed = false;
            _grabber = null;

            _rigidbody.useGravity = true;
            _rigidbody.linearVelocity = releaseVelocity;
            _rigidbody.angularVelocity = releaseAngularVelocity;

            ItemDropped?.Invoke(this);
        }

        /// <inheritdoc />
        public virtual void OnGrabMove(Vector3 targetPosition, Quaternion targetRotation)
        {
            // Handled in FixedUpdate via the stored grabber transform for
            // consistent physics-step timing; explicit calls are supported
            // for XR Interaction Toolkit compatibility.
            if (!_isGrabbed)
            {
                return;
            }

            _rigidbody.MovePosition(targetPosition);
            _rigidbody.MoveRotation(targetRotation);
        }

        #endregion

        #region IInteractable Implementation

        /// <inheritdoc />
        public virtual void OnInteract(GameObject interactor)
        {
            if (!interactor.TryGetComponent(out Transform interactorTransform))
            {
                interactorTransform = interactor.transform;
            }

            OnGrab(interactorTransform);
        }

        /// <inheritdoc />
        public virtual void OnFocusEnter()
        {
            // Override in derived classes or attach an OutlineHighlighter
            // component to visualize focus without hard-coding rendering here.
        }

        /// <inheritdoc />
        public virtual void OnFocusExit()
        {
        }

        #endregion

        #region Prank Behaviour Hook

        /// <summary>
        /// Called by an IPrankable slot when this item is successfully armed there.
        /// Derived classes (Banana, Soap, Glue, etc.) override this to trigger
        /// their specific prank effect (spawn slip trigger, spill hazard, etc.).
        /// Base implementation marks the item consumed and detaches it from inventory.
        /// </summary>
        public virtual void OnArmed()
        {
            IsConsumed = true;
            _isGrabbed = false;
            ItemConsumed?.Invoke(this);
        }

        #endregion

        #region Helpers

        /// <summary>Plays a one-shot sound through this item's AudioSource, if present.</summary>
        protected void PlaySound(AudioClip clip)
        {
            if (clip == null || _audioSource == null)
            {
                return;
            }

            _audioSource.PlayOneShot(clip);
        }

        /// <summary>
        /// Sends a haptic pulse to the controller that grabbed this item.
        /// Uses XR Interaction Toolkit's haptic API via the grabber's
        /// XRBaseController component if present; silently no-ops otherwise.
        /// </summary>
        protected void RequestHaptics(Transform grabber, float amplitude, float duration)
        {
            if (grabber == null)
            {
                return;
            }

            if (grabber.TryGetComponent(out UnityEngine.XR.Interaction.Toolkit.Interactors.XRBaseInputInteractor controller))
            {
                controller.SendHapticImpulse(amplitude, duration);
            }
        }

        #endregion
    }
}
