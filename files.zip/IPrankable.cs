using System;
using NeighboursFromHellVR.Items;

namespace NeighboursFromHellVR.Core.Interfaces
{
    /// <summary>
    /// Contract for a "prank slot" in the level - a location or object that can
    /// receive a prank item (e.g. a doorway for a banana peel, a chair for a
    /// whoopee cushion, a teapot for itching powder). Rottweiler AI listens to
    /// world state, but the prank trigger itself lives on the object implementing
    /// this interface.
    /// </summary>
    public interface IPrankable
    {
        /// <summary>Unique identifier used by ObjectiveManager/ScoreManager to track this prank slot.</summary>
        string PrankId { get; }

        /// <summary>Whether an item has already been armed at this slot.</summary>
        bool IsArmed { get; }

        /// <summary>Whether the prank has already been triggered/consumed.</summary>
        bool IsTriggered { get; }

        /// <summary>
        /// Raised when the prank successfully fires on the enemy.
        /// Payload is the score value awarded.
        /// </summary>
        event Action<int> OnPrankTriggered;

        /// <summary>
        /// Attempts to arm this slot with the given item.
        /// </summary>
        /// <param name="item">The prank item being placed.</param>
        /// <returns>True if the item was successfully armed at this slot.</returns>
        bool TryArm(Item item);

        /// <summary>
        /// Forces the prank to fire, typically called by enemy AI when it
        /// walks into / interacts with the armed slot.
        /// </summary>
        void TriggerPrank();

        /// <summary>Resets the slot back to its unarmed state (e.g. after a checkpoint reload).</summary>
        void ResetPrank();
    }
}
