using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using NeighboursFromHellVR.Core.Interfaces;

namespace NeighboursFromHellVR.Player
{
    /// <summary>
    /// Attached to each VR hand (LeftHand / RightHand). Handles detection,
    /// grabbing, holding and throwing of any object implementing
    /// <see cref="IGrabbable"/>. Maintains a short velocity history to
    /// compute realistic throw velocity from hand motion, since VR
    /// controller Rigidbodies don't carry meaningful physical velocity
    /// on their own.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ObjectGrabber : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Detection")]
        [Tooltip("Origin used to scan for nearby grabbable objects.")]
        [SerializeField] private Transform _grabOrigin;

        [Tooltip("Radius of the grab detection sphere.")]
        [SerializeField] private float _grabRadius = 0.1f;

        [Tooltip("Layers considered when scanning for grabbable objects.")]
        [SerializeField] private LayerMask _grabbableLayers;

        [Header("Input")]
        [SerializeField] private InputActionReference _gripAction;

        [Header("Throw Velocity Tracking")]
        [Tooltip("Number of previous frames used to average throw velocity.")]
        [SerializeField, Range(2, 10)] private int _velocitySampleCount = 5;

        #endregion

        #region Private Fields

        private readonly Collider[] _overlapBuffer = new Collider[16];
        private readonly Queue<Vector3> _positionHistory = new Queue<Vector3>();
        private readonly Queue<Quaternion> _rotationHistory = new Queue<Quaternion>();

        private IGrabbable _heldObject;
        private Vector3 _lastPosition;
        private Quaternion _lastRotation;

        #endregion

        #region Events

        /// <summary>Raised when this hand grabs an object. Payload: the grabbed MonoBehaviour's GameObject.</summary>
        public event Action<GameObject> ObjectGrabbed;

        /// <summary>Raised when this hand releases an object. Payload: the released MonoBehaviour's GameObject.</summary>
        public event Action<GameObject> ObjectReleased;

        #endregion

        #region Properties

        /// <summary>Whether this hand is currently holding something.</summary>
        public bool IsHolding => _heldObject != null;

        /// <summary>The object currently held by this hand, or null.</summary>
        public IGrabbable HeldObject => _heldObject;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            if (_grabOrigin == null)
            {
                _grabOrigin = transform;
            }
        }

        private void OnEnable()
        {
            if (_gripAction != null && _gripAction.action != null)
            {
                _gripAction.action.performed += HandleGripPerformed;
                _gripAction.action.canceled += HandleGripCanceled;
                _gripAction.action.Enable();
            }

            _lastPosition = _grabOrigin != null ? _grabOrigin.position : transform.position;
            _lastRotation = _grabOrigin != null ? _grabOrigin.rotation : transform.rotation;
        }

        private void OnDisable()
        {
            if (_gripAction != null && _gripAction.action != null)
            {
                _gripAction.action.performed -= HandleGripPerformed;
                _gripAction.action.canceled -= HandleGripCanceled;
            }
        }

        private void Update()
        {
            TrackVelocityHistory();
        }

        #endregion

        #region Input Handling

        private void HandleGripPerformed(InputAction.CallbackContext context)
        {
            if (_heldObject == null)
            {
                TryGrabNearest();
            }
        }

        private void HandleGripCanceled(InputAction.CallbackContext context)
        {
            if (_heldObject != null)
            {
                ReleaseHeldObject();
            }
        }

        #endregion

        #region Grab / Release

        /// <summary>
        /// Scans for the nearest valid IGrabbable within range and grabs it.
        /// Public so it can be triggered by XR Interaction Toolkit select
        /// events as an alternative to the raw Input System binding.
        /// </summary>
        public void TryGrabNearest()
        {
            int hitCount = Physics.OverlapSphereNonAlloc(
                _grabOrigin.position,
                _grabRadius,
                _overlapBuffer,
                _grabbableLayers,
                QueryTriggerInteraction.Collide);

            IGrabbable closest = null;
            GameObject closestObject = null;
            float closestSqrDistance = float.MaxValue;

            for (int i = 0; i < hitCount; i++)
            {
                Collider hitCollider = _overlapBuffer[i];
                if (hitCollider == null || !hitCollider.TryGetComponent(out IGrabbable grabbable))
                {
                    continue;
                }

                if (grabbable.IsGrabbed)
                {
                    continue;
                }

                float sqrDistance = (hitCollider.transform.position - _grabOrigin.position).sqrMagnitude;
                if (sqrDistance < closestSqrDistance)
                {
                    closestSqrDistance = sqrDistance;
                    closest = grabbable;
                    closestObject = hitCollider.gameObject;
                }
            }

            if (closest == null)
            {
                return;
            }

            _heldObject = closest;
            _heldObject.OnGrab(_grabOrigin);
            ObjectGrabbed?.Invoke(closestObject);
        }

        /// <summary>
        /// Releases the currently held object, applying velocity computed
        /// from recent hand motion so thrown items behave physically.
        /// </summary>
        public void ReleaseHeldObject()
        {
            if (_heldObject == null)
            {
                return;
            }

            (Vector3 velocity, Vector3 angularVelocity) = ComputeReleaseVelocity();

            IGrabbable released = _heldObject;
            GameObject releasedObject = released.GrabbableRigidbody != null
                ? released.GrabbableRigidbody.gameObject
                : null;

            _heldObject.OnRelease(velocity, angularVelocity);
            _heldObject = null;

            ObjectReleased?.Invoke(releasedObject);
        }

        #endregion

        #region Velocity Tracking

        /// <summary>
        /// Records recent hand position/rotation samples each frame, used
        /// to derive a smooth, realistic throw velocity on release rather
        /// than a single noisy frame delta.
        /// </summary>
        private void TrackVelocityHistory()
        {
            if (_grabOrigin == null)
            {
                return;
            }

            _positionHistory.Enqueue(_grabOrigin.position);
            _rotationHistory.Enqueue(_grabOrigin.rotation);

            while (_positionHistory.Count > _velocitySampleCount)
            {
                _positionHistory.Dequeue();
            }

            while (_rotationHistory.Count > _velocitySampleCount)
            {
                _rotationHistory.Dequeue();
            }
        }

        /// <summary>
        /// Averages the recorded position/rotation deltas into a linear
        /// and angular release velocity.
        /// </summary>
        private (Vector3 velocity, Vector3 angularVelocity) ComputeReleaseVelocity()
        {
            if (_positionHistory.Count < 2)
            {
                return (Vector3.zero, Vector3.zero);
            }

            Vector3[] positions = _positionHistory.ToArray();
            Quaternion[] rotations = _rotationHistory.ToArray();

            Vector3 velocitySum = Vector3.zero;
            Vector3 angularVelocitySum = Vector3.zero;
            int sampleCount = positions.Length - 1;

            for (int i = 0; i < sampleCount; i++)
            {
                velocitySum += (positions[i + 1] - positions[i]) / Time.deltaTime;

                Quaternion deltaRotation = rotations[i + 1] * Quaternion.Inverse(rotations[i]);
                deltaRotation.ToAngleAxis(out float angleDegrees, out Vector3 axis);

                if (float.IsInfinity(angleDegrees) || float.IsNaN(angleDegrees))
                {
                    continue;
                }

                if (angleDegrees > 180f)
                {
                    angleDegrees -= 360f;
                }

                angularVelocitySum += axis * (angleDegrees * Mathf.Deg2Rad / Time.deltaTime);
            }

            return (velocitySum / sampleCount, angularVelocitySum / sampleCount);
        }

        #endregion

        #region Gizmos

        private void OnDrawGizmosSelected()
        {
            Transform origin = _grabOrigin != null ? _grabOrigin : transform;
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(origin.position, _grabRadius);
        }

        #endregion
    }
}
