using UnityEngine;

namespace NeighboursFromHellVR.Core.Interfaces
{
    /// <summary>
    /// Base contract for any object in the world the player can interact with
    /// via a VR controller ray, grab, or trigger overlap.
    /// Implemented by doors, drawers, buttons, pranked items, hide spots, etc.
    /// </summary>
    public interface IInteractable
    {
        /// <summary>
        /// Human readable prompt shown in the world-space UI / crosshair tooltip,
        /// e.g. "Open Drawer", "Pick Up Banana".
        /// </summary>
        string InteractionPrompt { get; }

        /// <summary>
        /// Whether this object can currently be interacted with.
        /// Used to disable interaction while animating, locked, or already used.
        /// </summary>
        bool CanInteract { get; }

        /// <summary>
        /// Called by the InteractionManager when the player triggers
        /// an interaction (controller trigger press, hand pinch, etc.).
        /// </summary>
        /// <param name="interactor">The GameObject that initiated the interaction (usually the VR hand/controller).</param>
        void OnInteract(GameObject interactor);

        /// <summary>
        /// Called when the interaction focus (ray/hand) starts hovering this object.
        /// Used to trigger outline highlights or UI prompts.
        /// </summary>
        void OnFocusEnter();

        /// <summary>
        /// Called when the interaction focus (ray/hand) stops hovering this object.
        /// </summary>
        void OnFocusExit();
    }
}
