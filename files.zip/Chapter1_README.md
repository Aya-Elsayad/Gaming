# Chapter 1 — Core Interaction & Item System

**Neighbours From Hell VR** — Foundation chapter. Every later chapter (Player
Controller, Enemy AI, Levels, UI) depends on the interfaces and managers
built here, so this ships first.

---

## 1. Folder Structure

```
Assets/
└── Scripts/
    ├── Core/
    │   ├── Interfaces/
    │   │   ├── IInteractable.cs
    │   │   ├── IGrabbable.cs
    │   │   ├── IPrankable.cs
    │   │   └── IHideSpot.cs
    │   └── Interaction/
    │       └── InteractionManager.cs
    ├── Items/
    │   └── Item.cs
    └── Player/
        └── ObjectGrabber.cs
```

---

## 2. Scripts Delivered

| Script | Responsibility |
|---|---|
| `IInteractable` | Base contract for anything the player can look at / trigger-press (doors, drawers, buttons, items). |
| `IGrabbable` | Physics hand-off contract for objects that can be picked up and thrown. |
| `IPrankable` | Contract for prank "slots" in the world that an item can be armed at and that the enemy can trigger. |
| `IHideSpot` | Contract for hiding locations (under tables, inside cabinets). |
| `InteractionManager` | Per-hand component. Non-alloc sphere-scans for `IInteractable`s, manages focus enter/exit, dispatches `OnInteract`. Input-System driven. |
| `Item` | Abstract base class for all prank items. Implements both `IGrabbable` and `IInteractable`, handles hand-follow physics, pickup audio/haptics, and exposes an `OnArmed()` hook for derived items (Banana, Soap, Glue, etc. — Chapter 4). |
| `ObjectGrabber` | Per-hand component dedicated to grab/throw. Tracks a short position/rotation history to compute realistic release velocity, independent of the generic `InteractionManager` so doors/buttons don't get throw physics. |

> `IPrankable` and `IHideSpot` are defined now so downstream chapters can
> compile against them immediately, but their concrete implementations
> (`PrankSlot`, `HideSpotCabinet`, `HideSpotTable`) ship in Chapter 3
> alongside the Enemy AI vision system that queries them.

---

## 3. Scene Hierarchy (relevant subset)

```
XR Origin (XR Rig)
├── Camera Offset
│   └── Main Camera
├── LeftHand Controller
│   ├── InteractionManager   (Script: InteractionManager)
│   └── ObjectGrabber        (Script: ObjectGrabber)
└── RightHand Controller
    ├── InteractionManager   (Script: InteractionManager)
    └── ObjectGrabber        (Script: ObjectGrabber)

--- Level ---
Items
├── Banana_01                (Script: Banana — Chapter 4, uses Item base now)
├── Soap_01
└── Coffee_01
```

---

## 4. Inspector Setup

### InteractionManager (on each hand)
| Field | Value |
|---|---|
| Detection Origin | Hand's fingertip/palm transform |
| Detection Radius | `0.12` |
| Interactable Layers | `Interactable` |
| Max Overlap Results | `8` |
| Interact Action | `XRI LeftHand/Activate` or custom `Interact` action |

### ObjectGrabber (on each hand)
| Field | Value |
|---|---|
| Grab Origin | Hand's palm transform |
| Grab Radius | `0.10` |
| Grabbable Layers | `Grabbable` |
| Grip Action | `XRI LeftHand/Select` (grip button) |
| Velocity Sample Count | `5` |

### Item-derived prefabs (e.g. Banana)
| Field | Value |
|---|---|
| Item Id | `item_banana` |
| Display Name | `Banana` |
| Grab Position Offset | `(0, 0, 0.05)` (tune per mesh) |
| Follow Speed | `25` |
| Pickup Sound | assign clip |
| Pickup Haptic Amplitude | `0.3` |

---

## 5. Required Components

- **XR Interaction Toolkit** (package) — provides `XRBaseInputInteractor`
  used by `Item.RequestHaptics`.
- **Input System** (package) — all input is read via `InputActionReference`,
  no legacy `Input` calls.
- **Physics Layers**: create `Interactable` and `Grabbable` layers in
  Project Settings → Tags and Layers, and assign them to the corresponding
  colliders.
- Every prefab deriving from `Item` needs: `Rigidbody`, `Collider`
  (trigger for detection or physical, per item), `AudioSource`.

---

## 6. Prefab Setup

1. Create `Prefabs/Items/Item_Base.prefab`: empty GameObject with
   `Rigidbody` (useGravity on, isKinematic off), a `Collider` on layer
   `Grabbable`, and an `AudioSource` (Play On Awake off).
2. Derived item prefabs (Chapter 4) will variant off this base and attach
   their concrete `Item` subclass script plus mesh/material.
3. Hand prefabs (`LeftHand_Controller`, `RightHand_Controller`) each carry
   one `InteractionManager` + one `ObjectGrabber`, sharing the same
   Interact/Grip `InputActionReference` assets from the project-wide
   `Input Actions` asset (defined fully in Chapter 2 — Player Controller).

---

## 7. Git Commit Message

```
feat(core): add interaction interfaces, InteractionManager, Item base class, ObjectGrabber

- Add IInteractable, IGrabbable, IPrankable, IHideSpot interfaces
- Implement InteractionManager: non-alloc focus detection + Input System dispatch
- Implement abstract Item base class (IGrabbable + IInteractable, hand-follow physics, haptics)
- Implement ObjectGrabber: grab/release with velocity-history-based throw physics
- Establish Assets/Scripts folder structure for Core/Items/Player domains

Chapter 1 of Neighbours From Hell VR foundation.
```

---

## 8. Testing Instructions

1. **Setup**: Import XR Interaction Toolkit + Input System packages via
   Package Manager. Create `Interactable` and `Grabbable` layers.
2. **Smoke test scene**: Create an empty scene, add an `XR Origin (VR)`
   from the XRIT samples, attach `InteractionManager` and `ObjectGrabber`
   to each hand as described above.
3. **Dummy grabbable**: Create a Cube, add `Rigidbody`, set layer to
   `Grabbable`, add a temporary test `MonoBehaviour` implementing
   `IGrabbable` (or wait for `Banana` in Chapter 4) to confirm compile
   correctness end-to-end.
4. **Focus test**: In Play Mode (or using the XR Device Simulator), move a
   hand near the cube — confirm `FocusChanged` fires once per enter/exit
   (add a temporary `Debug.Log` subscriber).
5. **Grab test**: Hold grip near the cube — confirm it snaps to the hand
   and follows smoothly in `FixedUpdate`. Release grip while moving the
   hand — confirm the cube flies in the direction of hand motion, not with
   zero velocity.
6. **Regression check**: Ensure `InteractionManager` and `ObjectGrabber`
   do not both attempt to grab the same object (they operate on separate
   layers by design — verify `Interactable` and `Grabbable` layers are
   not accidentally merged on test objects).
7. **Compile check**: With XR Interaction Toolkit and Input System
   packages present, the project must build with zero errors/warnings in
   the Console for these five scripts.

---

**Next chapter (Chapter 2)** will build `PlayerController`, `VRHands`,
locomotion (smooth + teleport + snap turn), and the master `Input Actions`
asset that `InteractionManager`/`ObjectGrabber` reference.
