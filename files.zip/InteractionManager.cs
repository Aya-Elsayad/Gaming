using System;
using UnityEngine;
using NeighboursFromHellVR.Core.Interfaces;

namespace NeighboursFromHellVR.Core.Interaction
{
    /// <summary>
    /// Central interaction dispatcher. One instance exists per VR hand
    /// (attach to LeftHandInteractor and RightHandInteractor GameObjects).
    /// Detects nearby / focused IInteractable objects via a sphere overlap
    /// and raises events instead of other systems polling this manager
    /// directly, keeping coupling low per the project's "use events over
    /// direct references" convention.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class InteractionManager : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Detection Settings")]
        [Tooltip("Origin used for interactable overlap checks. Defaults to this transform if unset.")]
        [SerializeField] private Transform _detectionOrigin;

        [Tooltip("Radius of the sphere used to detect nearby interactables.")]
        [SerializeField] private float _detectionRadius = 0.12f;

        [Tooltip("Layers considered when scanning for interactables.")]
        [SerializeField] private LayerMask _interactableLayers;

        [Tooltip("Maximum number of colliders considered per scan (avoids GC allocs).")]
        [SerializeField] private int _maxOverlapResults = 8;

        [Header("Input")]
        [Tooltip("Reference to this hand's interact action (bound via Input System in the Player prefab).")]
        [SerializeField] private UnityEngine.InputSystem.InputActionReference _interactAction;

        #endregion

        #region Private Fields

        private readonly Collider[] _overlapBuffer = new Collider[16];
        private IInteractable _currentFocus;
        private GameObject _currentFocusObject;

        #endregion

        #region Events

        /// <summary>Raised when a new interactable gains focus. Payload: the focused GameObject.</summary>
        public event Action<GameObject> FocusChanged;

        /// <summary>Raised when an interaction is successfully performed. Payload: the interacted GameObject.</summary>
        public event Action<GameObject> InteractionPerformed;

        #endregion

        #region Properties

        /// <summary>The interactable currently focused by this hand, if any.</summary>
        public IInteractable CurrentFocus => _currentFocus;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            if (_detectionOrigin == null)
            {
                _detectionOrigin = transform;
            }

            if (_maxOverlapResults > _overlapBuffer.Length)
            {
                _maxOverlapResults = _overlapBuffer.Length;
            }
        }

        private void OnEnable()
        {
            if (_interactAction != null && _interactAction.action != null)
            {
                _interactAction.action.performed += HandleInteractActionPerformed;
                _interactAction.action.Enable();
            }
        }

        private void OnDisable()
        {
            if (_interactAction != null && _interactAction.action != null)
            {
                _interactAction.action.performed -= HandleInteractActionPerformed;
            }
        }

        private void Update()
        {
            ScanForInteractable();
        }

        #endregion

        #region Detection

        /// <summary>
        /// Performs a non-allocating overlap sphere to find the closest valid
        /// interactable in range, updating focus state and firing focus events.
        /// </summary>
        private void ScanForInteractable()
        {
            int hitCount = Physics.OverlapSphereNonAlloc(
                _detectionOrigin.position,
                _detectionRadius,
                _overlapBuffer,
                _interactableLayers,
                QueryTriggerInteraction.Collide);

            IInteractable closest = null;
            GameObject closestObject = null;
            float closestSqrDistance = float.MaxValue;

            for (int i = 0; i < hitCount; i++)
            {
                Collider hitCollider = _overlapBuffer[i];
                if (hitCollider == null)
                {
                    continue;
                }

                if (!hitCollider.TryGetComponent(out IInteractable interactable))
                {
                    continue;
                }

                if (!interactable.CanInteract)
                {
                    continue;
                }

                float sqrDistance = (hitCollider.transform.position - _detectionOrigin.position).sqrMagnitude;
                if (sqrDistance < closestSqrDistance)
                {
                    closestSqrDistance = sqrDistance;
                    closest = interactable;
                    closestObject = hitCollider.gameObject;
                }
            }

            UpdateFocus(closest, closestObject);
        }

        /// <summary>
        /// Transitions focus between interactables, firing OnFocusEnter/Exit
        /// callbacks and the FocusChanged event.
        /// </summary>
        private void UpdateFocus(IInteractable newFocus, GameObject newFocusObject)
        {
            if (ReferenceEquals(newFocus, _currentFocus))
            {
                return;
            }

            _currentFocus?.OnFocusExit();

            _currentFocus = newFocus;
            _currentFocusObject = newFocusObject;

            _currentFocus?.OnFocusEnter();

            FocusChanged?.Invoke(_currentFocusObject);
        }

        #endregion

        #region Input Handling

        /// <summary>
        /// Bound to the hand's "Interact" Input System action. Dispatches
        /// the interaction to whichever object currently has focus.
        /// </summary>
        private void HandleInteractActionPerformed(UnityEngine.InputSystem.InputAction.CallbackContext context)
        {
            TryInteract();
        }

        /// <summary>
        /// Attempts to interact with the currently focused object.
        /// Public so it can also be invoked from XR Interaction Toolkit
        /// select events if preferred over raw Input System bindings.
        /// </summary>
        public void TryInteract()
        {
            if (_currentFocus == null || !_currentFocus.CanInteract)
            {
                return;
            }

            _currentFocus.OnInteract(gameObject);
            InteractionPerformed?.Invoke(_currentFocusObject);
        }

        #endregion

        #region Gizmos

        private void OnDrawGizmosSelected()
        {
            Transform origin = _detectionOrigin != null ? _detectionOrigin : transform;
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(origin.position, _detectionRadius);
        }

        #endregion
    }
}
