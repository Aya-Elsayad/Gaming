using UnityEngine;

namespace NeighboursFromHellVR.Core.Interfaces
{
    /// <summary>
    /// Contract for any location the player can hide in/under to break enemy
    /// line of sight (cabinets, under tables, behind curtains). The enemy AI's
    /// vision-cone check queries <see cref="ConcealsPlayer"/> to determine
    /// whether a hidden player counts as visible.
    /// </summary>
    public interface IHideSpot
    {
        /// <summary>Transform the player's camera rig snaps to while hidden.</summary>
        Transform HidePosition { get; }

        /// <summary>Whether the player is currently occupying this hide spot.</summary>
        bool IsOccupied { get; }

        /// <summary>Whether this spot is free (not occupied and not obstructed).</summary>
        bool IsAvailable { get; }

        /// <summary>
        /// While the player is inside this spot, whether it currently
        /// fully conceals them from enemy vision (some spots like glass
        /// cabinets may only partially conceal).
        /// </summary>
        bool ConcealsPlayer { get; }

        /// <summary>
        /// Called when the player enters the hide spot.
        /// </summary>
        /// <param name="occupant">The player GameObject entering.</param>
        void OnEnterHide(GameObject occupant);

        /// <summary>
        /// Called when the player exits the hide spot.
        /// </summary>
        void OnExitHide();
    }
}
